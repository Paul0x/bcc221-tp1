/***************************************************************************
 *  Trabalho Prático 1 - Programação Orientada a Objetos BCC 221 - 2020.1
 *  Paulo Felipe Possa Parreira - 12.2.1165
 *  paulof@ufop.edu.br
 *  02/2021
 * 
 *  Main Source File
 ***************************************************************************/

#include <cstdlib>
#include <SistemaClinica.h>
using namespace std;

int main(int argc, char** argv) {
    SistemaClinica sistema = SistemaClinica();
    sistema.initUsuarios();
    sistema.initSistema();
    return 0;
}

